import React from 'react'

class CurrencyConverter extends React.Component {
    constructor() {
            super();
            this.state = {
                baseCurrency: 'AUD',
                convertToCurrency: 'USD',
                initialAmount: 100,
				rates: {"USD":0.837 ,"CAD":0.8711,"CNY":6.1715 ,"EUR":1.2315 ,"GBP":1.5683 ,"NZD":0.7750 ,"JPY":119.95,"EUR":27.602,"DKK":7.4405 ,"NOK":8.6651,"AUD":1} ,
                currencies: ['AUD','CAD','CNY','CZK','DKK','EUR','GBP','JPY','NOK','NZD','USD']
            };
        }
    changeBaseCurrency = (e) => {
        this.setState({ baseCurrency: e.target.value });
    }

    convertCurrency = (e) => {
        this.setState({ convertToCurrency: e.target.value });
    }

    changeBaseAmount = (e) => {
        this.setState({ initialAmount: e.target.value });
    }

    render() {
	var {currencies,rates,baseCurrency,initialAmount,convertToCurrency} = this.state;
	var convertedValue =  Number.parseFloat(initialAmount * rates[convertToCurrency]).toFixed(2);
	if(convertedValue === "NaN"){
		alert("Unable to find rate for  " +  (baseCurrency+"/"+convertToCurrency))
		window.location.reload();
	}
        return (<div className="form-container">
        <form className='ui mini form'>
        <h2> Currency Converter React Application </h2>
		<hr/>
         <h3>Convert from: {baseCurrency}</h3>
          <select  value={baseCurrency} onChange={this.changeBaseCurrency}>
            {currencies.map(currency =><option key={currency} value={currency}> {currency} </option>)}
          </select>
        
          <h3>Convert to: {convertToCurrency}</h3>
          <select value={convertToCurrency} onChange={this.convertCurrency}>
            {currencies.map(currency =><option key={currency} value={currency}> {currency} </option>)}
          </select>
        
         <h3>Amount:</h3>
           <input type='number' id='base-amount' defaultValue={initialAmount} onChange={this.changeBaseAmount}/>                          
       </form>                       
       <h2 id='result-text'>{initialAmount} {baseCurrency} is equal to {convertedValue} {convertToCurrency}</h2>
     </div>)
    }
}
export default CurrencyConverter;