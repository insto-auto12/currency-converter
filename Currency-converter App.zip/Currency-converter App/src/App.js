import React from 'react';
import './App.css';
import CurrencyCoverter from './Components/CurrencyConverter.js';

function App() {
    return ( <div className = "App" >
        <CurrencyCoverter/>
        </div>
    );
}

export default App;