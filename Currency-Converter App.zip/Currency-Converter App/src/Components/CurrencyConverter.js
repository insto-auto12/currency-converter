import React from 'react'

class CurrencyConverter extends React.Component {
    constructor() {
            super();
            this.state = {
                baseCurrency: 'GBP',
                convertToCurrency: 'USD',
                initialAmount: 100,
                rates: [],
                currencies: []
            };
        }
    //Invoked once when the component is called this.getDataFromServer method is called to get data from server
    componentDidMount() {
        this.getDataFromServer(this.state.baseCurrency)
    }

    getDataFromServer = (base) => {
        const api = `https://api.exchangeratesapi.io/latest?base=${base}`; // API to get data https://api.exchangeratesapi.io/latest
        fetch(api)
            .then(results => {
                //  console.log(results)
                return results.json();
            }).then(data => {
                console.log("server data", data);
                this.setState({ rates: data['rates'], currencies: Object.keys(data['rates']).sort() })
            });
    }

    changeBaseCurrency = (e) => {
        //   console.log("convert from currency ->", e.target.value) //INR is returned after onchange is fired for example
        this.setState({ baseCurrency: e.target.value });
        this.getDataFromServer(e.target.value)
    }

    convertCurrency = (e) => {
        //    console.log("convert to currency" ,e.target.value) //By default USD is returned unless we do onchange
        this.setState({ convertToCurrency: e.target.value });
    }

    changeBaseAmount = (e) => {
        //    console.log("Entered value by user",e.target.value) //After onchange for example 100
        this.setState({ initialAmount: e.target.value });
    }

    getConvertedCurrency = (initialAmount, convertToCurrency, rates) => {
        console.log(rates)
            /*Calculation Part
			initialAmount = this.state.initialAmount = 100
			baseCurrency = this.state.baseCurrency = INR
			convertToCurrency =this.state.convertToCurrency = USD
			parseFloat("100" * "0.0139026549").toFixed(2) will yield 1.39 USD
			*/
        return Number.parseFloat(initialAmount * rates[convertToCurrency]).toFixed(2);
    }

    render() {
	const {currencies,rates,baseCurrency,initialAmount,convertToCurrency} = this.state;
	const convertedValue = this.getConvertedCurrency(initialAmount, convertToCurrency, rates);
        return (<div className="form-container">
        <form className='ui mini form'>
         <h2> Currency Converter React Application </h2>
		<hr/>
         <h3>Convert from: {baseCurrency}</h3>
          <select  value={baseCurrency} onChange={this.changeBaseCurrency}>
            {currencies.map(currency =><option key={currency} value={currency}> {currency} </option>)}
          </select>
        
          <h3>Convert to: {convertToCurrency}</h3>
          <select value={convertToCurrency} onChange={this.convertCurrency}>
            {currencies.map(currency =><option key={currency} value={currency}> {currency} </option>)}
          </select>
        
         <h3>Amount:</h3>
           <input type='number' id='base-amount' defaultValue={initialAmount} onChange={this.changeBaseAmount}/>                          
       </form>                       
       <h2 id='result-text'>{initialAmount} {baseCurrency} is equal to {convertedValue} {convertToCurrency}</h2>
     </div>)
    }
}
export default CurrencyConverter;